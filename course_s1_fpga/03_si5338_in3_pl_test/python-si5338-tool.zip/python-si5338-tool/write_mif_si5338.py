
# This function generates a 'coe' file which suits for
# Xilinx ISE FPGA-tool (initialization value for BRAM)
#   'data'
#       vector or a matrix
#   'filename'
#       the name of the desired output file
#
#   copyright by:
#       Steffen Mauch (C) 2013
#       email: steffen.mauch (at) gmail.com
# 
# The MIT License (MIT)
#
# Copyright (c) 2013 Steffen Mauch
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.


def write_mif_si5338(data, filename):
	f = open(filename, 'w')
	sizeA = len(data)
	sizeB = len(data[0])

	for l in range(0,sizeA):
		for k in range(0,sizeB):
			tmp = bin(data[l][k]).replace('0b','')
			tmp = tmp.zfill(8)
			f.write('%s' % tmp )
		f.write('\n')

	f.close()

#write_coe_si5338(1,1)

ClockBuilder Desktop Software 

Silicon Laboratories
http://www.silabs.com/



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PC System Requirements
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- Microsoft Windows 2000, Windows XP, Windows Vista, Windows 7
- USB 2.0 
- 7 MB of free hard drive space 
- 1024 x 768 screen resolution or greater 
- Microsoft .NET Framework 4.0  
- USBXpress 3.3 driver
- Text size setting of 100% scaling and 96 DPI are highly recommended

Note: USBXpress 3.3 driver is provided and installed 
with the software. Newer or older versions of USBXpress 
available from other EVB kits or online have not been 
tested with this software.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Quick Start
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Install the ClockBuilder Desktop Software. 
(Assumes that Microsoft .NET Framework 4.0 is already 
installed. See the next section for more information.)
Also allow the driver to be installed.

2. Connect a USB cable from the EVB to the PC where the 
software was installed.

3. Launch the ClockBuilder Desktop Software by clicking on Start > 
Programs > Silicon Laboratories > Si5338-34-35-56 ClockBuilder Desktop X.X
and selecting one of the programs.

4. See the online help in any program available in the
Help menu option for more information.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Microsoft .NET Framework 4.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The Microsoft .NET Framework is required before installing 
and running the software. Details and
installation information about the .NET Framework are 
available via a shortcut in the NETFramework directory or at
the following web site:

http://msdn.microsoft.com/en-us/netframework/aa569263

There are multiple versions of the .NET Framework available 
from Microsoft, and they can be installed side-by-side
on the same computer. The software requires version 4.0. 

Contact your system administrator for more details.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
ClockBuilder Desktop Software
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To install:
1. Navigate to the install directory.

2. Double-click the install exe file.

3. Follow the steps in the wizard to install the program.

4. After the installation is complete, click on Start >
Programs > Silicon Laboratories > Si5338-34-35-56 ClockBuilder Desktop X.X. 
Select one of the programs to control the EVB.

5. See the online help available in one of the programs
via the Help menu option.


To uninstall:

NOTE: Close all the programs before running the uninstaller to 
ensure complete removal of the software.

The driver software must be uninstalled separately. 
See the next section for details.

To uninstall the software, use the Add and Remove 
Programs utility in the Control Panel. 

Or double-click on the Uninstal.exe file in the 
where the software is installed originally.




~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Si5338 EVB Kit, Si5356 EVB Kit, and 
Si5338 PROG Kit Driver (USBXpress 3.3)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The EVB uses the Silicon Laboratories� USBXpress 3.3 driver to 
allow the EVB to communicate with the computer via USB. Other
versions have not been tested with this software or EVB.

The driver is installed after the EVB software is installed. If
this option is cancelled then the EVB will not run with the computer
via USB.

The installer will copy the necessary driver files and 
update the operating system. However, for every different 
EVB connected to the same computer, the hardware installation 
wizard will run to associate this driver with the new EVB. 
Let the wizard run with its default settings.

The USBXpress driver may be removed via the Add and Remove 
Programs utility in the Control Panel. Locate the entry 
called Silicon Laboratories USBXpress Device. Click the 
button and it should show the version and location of 
what it will remove.

The USBXpress 3.3 installation files are located with the 
installed Si5338-34-35-56 ClockBuilder Desktop X.X. 
The driver files for the EVB may be re-installed from this 
location or by running the EVB install software.

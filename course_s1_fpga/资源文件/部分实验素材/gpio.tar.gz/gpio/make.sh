#!/bin/bash

source /opt/Xilinx/Vivado/2017.4/settings64.sh
arm-linux-gnueabihf-gcc  gpio.c -o gpio


#!/bin/sh

gpio_test() {
	gpio=$1
	echo $gpio > /sys/class/gpio/export
	echo out > /sys/class/gpio/gpio${gpio}/direction
	for i in $(seq 1 3) 
	do
	echo 0 >/sys/class/gpio/gpio${gpio}/value
	sleep 1
	echo 1 >/sys/class/gpio/gpio${gpio}/value
	sleep 1
	done
	echo $gpio > /sys/class/gpio/unexport
}

gpio_test 898
gpio_test 1016
gpio_test 1017
gpio_test 1018
gpio_test 1019
